package com.example.composetutorial


import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

@Composable
fun SettingScreen(navController: NavController, context: Context) {
    val lightValue = remember { mutableFloatStateOf(0f) }
    val sensorListener = remember { SensorListener(context) { lux -> lightValue.floatValue = lux }
    }
    val database = remember { AppDatabase.getDatabase(context) }
    val userDao = remember { database.userDao() }
    val scope = rememberCoroutineScope()
    var usernameInput by remember { mutableStateOf(TextFieldValue("")) }
    var profileImageUri by remember { mutableStateOf<Uri?>(null) }

    val activity = LocalContext.current as? MainActivity

    Button(onClick = {
        activity?.showNotification()
    }) {
        Text("Send a test notification")
    }

    DisposableEffect(Unit) {
        sensorListener.register()
        onDispose { sensorListener.unregister() }
    }

    LaunchedEffect(Unit) {
        val user = userDao.getUser()
        user?.let { it ->
            usernameInput = TextFieldValue(it.username)
            profileImageUri = it.profileImageUri?.let { Uri.parse(it)}
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val savedImagePath = saveImageToInternalStorage(context, uri)
            profileImageUri = savedImagePath?.let { Uri.fromFile(File(it)) }
        }
    }
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = {
            launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) {
            Text(text = "Choose a profile image")
        }

        profileImageUri?.let { image ->
            AsyncImage(
                model = image,
                contentDescription = "Selected Image",
                modifier = Modifier.size(150.dp).padding(16.dp)
            )
        }

        TextField(
            value = usernameInput,
            onValueChange = { usernameInput = it },
            label = { Text("Change your username") },
            modifier = Modifier.padding(16.dp)
        )
        Button(onClick =  {
            scope.launch {
                val user = User(username = usernameInput.text, profileImageUri = profileImageUri?.path)

                userDao.insertUser(user)
            }
        }) {
            Text(text = "SAVE CHANGES")
        }

        Button(onClick = {
            navController.navigate("MessageFeed") {
                popUpTo("MessageFeed") { inclusive = true }
            }
        }) {
            Text(text = "Go back to messages")
        }
        Spacer(modifier = Modifier.height(30.dp))
        Column(
            horizontalAlignment = Alignment.CenterHorizontally) {

            Text(text = "Ambient Light: ${"%.1f".format(lightValue.floatValue)} lux")
            if (lightValue.floatValue >= 32000) {
                Text(text = "That's way too bright for an ICT student, go back indoors!",
                    fontSize = 16.sp)
            }
        }
    }
}
fun saveImageToInternalStorage(context: Context, uri: Uri): String? {
    val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
    val file = File(context.filesDir, "profile_image.jpg")

    inputStream?.use { input ->
        FileOutputStream(file).use { output ->
            input.copyTo(output)
        }
    }
    return file.absolutePath
}





