package com.example.composetutorial

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun SettingScreen(navController: NavController, context: Context) {
    val database = remember { AppDatabase.getDatabase(context) }
    val userDao = remember { database.userDao() }
    val scope = rememberCoroutineScope()
    var usernameInput by remember { mutableStateOf(TextFieldValue("")) }
    var profileImageUri by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(Unit) {
        val user = userDao.getUser()
        user?.let { it ->
            usernameInput = TextFieldValue(it.username)
            profileImageUri = it.profileImageUri?.let { Uri.parse(it)}
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            profileImageUri = uri
            Log.d("SettingScreen", "Selected URI: $uri")
        }
    }
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = {
            launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) {
            Text(text = "Change profile picture")
        }

        profileImageUri?.let { image ->
            AsyncImage(
                model = image,
                contentDescription = "Selected Image",
                modifier = Modifier.size(150.dp).padding(16.dp)
            )
        }

        TextField(
            value = usernameInput,
            onValueChange = { usernameInput = it },
            label = { Text("CHANGE YOUR USERNAME") },
            modifier = Modifier.padding(16.dp)
        )
        Button(onClick =  {
            scope.launch {
                val user = User(username = usernameInput.text, profileImageUri = profileImageUri?.toString())
                userDao.insertUser(user)
            }
        }) {
            Text(text = "Save username")
        }

        Button(onClick = {
            navController.navigate("MessageFeed") {
                popUpTo("MessageFeed") { inclusive = true }
            }
        }) {
            Text(text = "Go back to messages")
        }

    }
}


