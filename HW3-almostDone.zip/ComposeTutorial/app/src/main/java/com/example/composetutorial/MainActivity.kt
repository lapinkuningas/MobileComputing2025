package com.example.composetutorial

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import android.content.Context

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()

            NavHost(
                navController = navController, startDestination = "MessageFeed"
            ) {
                composable("MessageFeed") {
                    MessageFeedScreen(navController, this@MainActivity)
                }
                composable("SettingScreen") {
                    SettingScreen(navController, this@MainActivity)
                }
            }
        }
    }
}
