package com.example.composetutorial

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

@Composable
fun SettingScreen(navController: NavController, context: Context) {
    val database = remember { AppDatabase.getDatabase(context) }
    val userDao = remember { database.userDao() }
    val scope = rememberCoroutineScope()
    var usernameInput by remember { mutableStateOf(TextFieldValue("")) }
    var profileImageUri by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(Unit) {
        val user = userDao.getUser()
        user?.let { it ->
            usernameInput = TextFieldValue(it.username)
            profileImageUri = it.profileImageUri?.let { Uri.parse(it)}
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val savedImagePath = saveImageToInternalStorage(context, uri)
            profileImageUri = savedImagePath?.let { Uri.parse(it) }
        }
    }
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = {
            launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) {
            Text(text = "Choose a profile image")
        }

        profileImageUri?.let { image ->
            AsyncImage(
                model = image,
                contentDescription = "Selected Image",
                modifier = Modifier.size(150.dp).padding(16.dp)
            )
        }

        TextField(
            value = usernameInput,
            onValueChange = { usernameInput = it },
            label = { Text("Change your username") },
            modifier = Modifier.padding(16.dp)
        )
        Button(onClick =  {
            scope.launch {
                val user = User(username = usernameInput.text, profileImageUri = profileImageUri?.toString())
                userDao.insertUser(user)
            }
        }) {
            Text(text = "SAVE CHANGES")
        }

        Button(onClick = {
            navController.navigate("MessageFeed") {
                popUpTo("MessageFeed") { inclusive = true }
            }
        }) {
            Text(text = "Go back to messages")
        }

    }
}
fun saveImageToInternalStorage(context: Context, uri: Uri): String? {
    val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
    val file = File(context.filesDir, "profile_image.jpg")

    inputStream?.use { input ->
        FileOutputStream(file).use { output ->
            input.copyTo(output)
        }
    }
    return file.absolutePath
}


